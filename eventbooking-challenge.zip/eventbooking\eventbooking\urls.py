from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/events/", include("events.urls")),
    path("api/bookings/", include("bookings.urls")),
    path("api/coupons/", include("coupons.urls")),
]
